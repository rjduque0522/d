import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import javax.print.DocFlavor.URL;
import java.util.concurrent.TimeUnit;


public class AppiumTest {

    static AppiumDriver<MobileElement> driverAppium;

    public static void main(String[] args)  {
        openApp();
    }
        public static void openApp() {

            DesiredCapabilities cap = new DesiredCapabilities();
            cap.setCapability("deviceName", "Redmi 9");
            cap.setCapability("udid", "39aacc860502");
            cap.setCapability("platformName", "Android");
            cap.setCapability("platformVersion", "11");
            cap.setCapability("appPackage", "com.loginmodule.learning");
            cap.setCapability("appActivity", "com.loginmodule.learning.activities.LoginActivity");
            driverAppium = new AppiumDriver<MobileElement>(cap);
            //URL url = new URL("http://127.0.0.1:4723/wd/hub");
            System.out.println("Automated Application Started");

            //Login
            driverAppium.findElement(By.id("com.loginmodule.learning:id/textInputEditTextEmail")).sendKeys("rjduque3gmail.com");
            driverAppium.findElement(By.id("com.loginmodule.learning:id/textInputEditTextPassword")).sendKeys("960522");
            MobileElement AceptarBoton = driverAppium.findElement(By.id("com.loginmodule.learning:id/appCompatButtonLogin"));
            AceptarBoton.click();


        }

}
